
 Apache HTTP Server 2.4 Limited OpenSSL Distribution

 This binary installation of OpenSSL is a limited distribution of the
 files derived from the OpenSSL project:

   LICENSE.txt (includes openssl LICENSE)
   OPENSSL-NEWS.txt
   OPENSSL-README.txt
   conf\openssl.cnf
   bin\libeay32.dll
   bin\ssleay32.dll
   bin\openssl.exe

 These are the minimal libraries and tools required to use mod_ssl as 
 distributed with Apache HTTP Server version 2.4.  No library link files, 
 headers or sources are distributed with this binary distribution.  Please 
 refer to the <http://www.openssl.org/> site for complete source or binary 
 distributions.

 These OpenSSL binaries were built for distribution from the U.S. without 
 support for the patented encryption methods IDEA, MDC-2 or RC5.

 The Apache HTTP Project only supports the binary distribution of these files
 and development of the mod_ssl module.  We cannot provide support assistance
 for using or configuring the OpenSSL package or these modules.  Please refer
 all installation and configuration questions to the appropriate forum,
 such as the user supported lists, <http://httpd.apache.org/userslist.html> 
 the Apache HTTP Server user's list or <http://www.openssl.org/support/> the
 OpenSSL support page.

--------------------------------------------------------------------------------

